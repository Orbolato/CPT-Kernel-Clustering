classZero=0 # Keep it 0
nclass=9 # Change to 4 for the erosion dataset

# Predictions

predictions=predict(model,mdatab[,1:iniCols])
preds=predictions
for(p in 1:nrow(preds)){
  for(q in 1:ncol(preds)){
    if(preds[p,q]==max(preds[p,])){
      preds[p,q]=1
    }else{
      preds[p,q]=0
    }
  }
}

# Calculating accuracy

mp=0

for(j in classZero:nclass){
  mp=mp+sum(preds[preds[,j+1-classZero]==mdatab[,iniCols+j+1-classZero],j+1-classZero])/sum(mdatab[,iniCols+j+1-classZero])
}

mp=mp/(nclass-classZero+1)

cat("Accuracy:",mp*100,"%\n\n")