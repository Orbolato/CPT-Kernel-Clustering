
##############################################################################
#Reading .csv file and saving the data in a variable

path1 = file.path("C:","Users","Orbolato","Desktop","Mestrado","Dados","Base Integrada","N�o Supervisionado","completa.csv")
completa = read.table(path1, header = TRUE, sep = ",", stringsAsFactor = FALSE)

path2 = file.path("C:","Users","Orbolato","Desktop","Mestrado","Dados","Base Integrada","N�o Supervisionado","metro.csv")
metro = read.table(path2, header = TRUE, sep = ",", stringsAsFactor = FALSE)

path3 = file.path("C:","Users","Orbolato","Desktop","Mestrado","Dados","Base Integrada","N�o Supervisionado","cunha.csv")
cunha = read.table(path3, header = TRUE, sep = ",", stringsAsFactor = FALSE)

path4 = file.path("C:","Users","Orbolato","Desktop","Mestrado","Dados","Base Integrada","N�o Supervisionado","erosao.csv")
erosao = read.table(path4, header = TRUE, sep = ",", stringsAsFactor = FALSE)

path5 = file.path("C:","Users","Orbolato","Desktop","Mestrado","Dados","Base Integrada","Erosao","conf.csv")
confusion = read.table(path5, header = TRUE, sep = ",", stringsAsFactor = FALSE)

dataNet=rbind(completa,metro,cunha,erosao)

dataNet[,"MSBTn"]=as.factor(as.character(dataNet[,"MSBTn"]))
dataNet[,"SBTn"]=as.factor(as.character(dataNet[,"SBTn"]))
confusion[,"Cspt"]=as.factor(as.character(confusion[,"Cspt"]))

# Histogram plotting
##############################################################################

library(ggplot2)
library(scales)

# Histogram for Robertson (1991)

h1 <- ggplot(data=dataNet,aes(x=dataNet$SBTn)) +
  geom_histogram(color="black", aes(y = (..count..)/sum(..count..),fill=SBTn), stat="count", show.legend=F) +
  scale_y_continuous(labels=percent,limits=c(0,0.6)) +
  labs(x=NULL,y=NULL,title=NULL) +
  theme(text = element_text(size=40),
        axis.text.x = element_text(hjust=1))

plot(h1)

# Histogram for Robertson (2016)

h2 <- ggplot(data=dataNet,aes(x=dataNet$MSBTn)) +
  geom_histogram(color="black", aes(y = (..count..)/sum(..count..),fill=MSBTn), stat="count", show.legend=F) +
  scale_y_continuous(labels=percent,limits=c(0,0.6)) +
  labs(x=NULL,y=NULL,title=NULL) +
  theme(text = element_text(size=40),
        axis.text.x = element_text(hjust=1))

show(h2)

# Histogram for SPT

h3 <- ggplot(data=confusion,aes(x=confusion$Cspt)) +
  geom_histogram(color="black", aes(y = (..count..)/sum(..count..),fill=Cspt), stat="count", show.legend=F) +
  scale_y_continuous(labels=percent,limits=c(0,0.8)) +
  labs(x=NULL,y=NULL,title=NULL) +
  theme(text = element_text(size=40),
        axis.text.x = element_text(hjust=1))

show(h3)

# Proportion check
##############################################################################

# Number of elements by class for Robertson (1991)

for(i in sort(unique(dataNet$SBTn))){
  cat("Class", i, ":", nrow(dataNet[dataNet$SBTn==i,]),"\n")
}

cat("Total:", nrow(dataNet), "\n")

# Number of elements by class for Robertson (2016)

for(i in sort(unique(dataNet$MSBTn))){
  cat("Class", i, ":", nrow(dataNet[dataNet$MSBTn==i,]),"\n")
}

cat("Total:", nrow(dataNet), "\n")

# Number of elements by class for SPT

for(i in sort(unique(confusion$Cspt))){
  cat("Class", i, ":", nrow(confusion[confusion$Cspt==i,]),"\n")
}

cat("Total:", nrow(confusion), "\n")
