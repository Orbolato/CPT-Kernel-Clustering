##############################################################################
# Clustering packages

library("e1071") # C-means
library("kernlab") # kkmeans
library("stats") # K-means
fpath=file.path("C:\\Users\\ORBOLATO\\Desktop\\Mestrado\\Dados\\Base integrada\\N�o supervisionado\\xmeans.R")
source(fpath) # X-means
library("compiler")
enableJIT(3)
library("parallel")
library("RSNNS")

##############################################################################
#Reading .csv file and saving the data in a variable

path1 = file.path("C:","Users","Orbolato","Desktop","Mestrado","Dados","Base Integrada","N�o Supervisionado","completa.csv")
completa = read.table(path1, header = TRUE, sep = ",", stringsAsFactor = FALSE)

path2 = file.path("C:","Users","Orbolato","Desktop","Mestrado","Dados","Base Integrada","N�o Supervisionado","metro.csv")
metro = read.table(path2, header = TRUE, sep = ",", stringsAsFactor = FALSE)

path3 = file.path("C:","Users","Orbolato","Desktop","Mestrado","Dados","Base Integrada","N�o Supervisionado","cunha.csv")
cunha = read.table(path3, header = TRUE, sep = ",", stringsAsFactor = FALSE)

path4 = file.path("C:","Users","Orbolato","Desktop","Mestrado","Dados","Base Integrada","N�o Supervisionado","erosao.csv")
erosao = read.table(path4, header = TRUE, sep = ",", stringsAsFactor = FALSE)

path5 = file.path("C:","Users","Orbolato","Desktop","Mestrado","Dados","Base Integrada","Erosao","conf_2.csv")
confusion = read.table(path5, header = TRUE, sep = ",", stringsAsFactor = FALSE)

#dataNet=rbind(completa,metro,cunha,erosao)
dataNet=erosao

##############################################################################
# k-Means

# R package

library(stats)

# Defining dataset and inputs

data=dataNet
inp=c("Qtn","Fr_p")
out="SBTn"
par(mfrow=c(1,2))

# Defining formula

form=paste(inp,collapse="+")
form=as.formula(paste(append(out,form),collapse="~"))

# # Removing Robertson (1991) class 0
# 
# data=data[data[,out]!=0,]

# # Getting samples of each class
# 
# nsamples=200
# 
# for(i in unique(data[,out])){
#   if(nrow(data[data[,out]==i,])>nsamples){
#     set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
#     idx=sample(nrow(data[data[,out]==i,]),nsamples)
#     add=data[data[,out]==i,]
#     add=add[idx,]
#     data=rbind(data[data[,out]!=i,],add)
#   }
# }
# for(i in unique(data[,out])){
#   show(nrow(data[data[,out]==i,]))
# }

mdata=as.matrix(data)

# Statistical marks for pre-filtering

q1=c()
q3=c()

for(class in sort(unique(mdata[,out]))){
  auxq1=c()
  auxq3=c()
  for(at in inp[inp!="Depth_m"]){

    # First quartile

    auxq1=append(auxq1,quantile(mdata[mdata[,out]==class,at])[2])

    # Third quartile

    auxq3=append(auxq3,quantile(mdata[mdata[,out]==class,at])[4])

  }
  q1=cbind(q1,auxq1)
  q3=cbind(q3,auxq3)
}


# Interquartil interval

iq=q3-q1

# Formating

q1=t(as.matrix(q1))
colnames(q1)=inp[inp!="Depth_m"]
rownames(q1)=sort(unique(mdata[,out]))

q3=t(as.matrix(q3))
colnames(q3)=inp[inp!="Depth_m"]
rownames(q3)=sort(unique(mdata[,out]))

iq=t(as.matrix(iq))
colnames(iq)=inp[inp!="Depth_m"]
rownames(iq)=sort(unique(mdata[,out]))

# Data cleaning

removed=0
idx=c()

# Pre-filtering

cat("\nPre-filtering\n")

for(obj in 1:nrow(mdata)){
  class=as.character(mdata[obj,out])
  for(at in inp[inp!="Depth_m"]){
    if(mdata[obj,at]>q3[class,at]+1.5*iq[class,at]
       || mdata[obj,at]<q1[class,at]-1.5*iq[class,at]){
      if(length(idx)==0 || obj!=idx[length(idx)]){
        idx=append(idx,obj)
        #cat("Pre-filtered:",length(idx),"\n")
        #cat("Object:",obj,"\n\n")
      }
    }
  }
}

# Data frame of the data set

data=as.data.frame(mdata)

# Converting outputs of the data frames into factors

data[,out]=as.factor(data[,out])

# # Filtering
# 
# cat("\nFiltering\n")
# 
# filt=0
# 
# for(obj in 1:length(idx)){
#   fitTrain <- kknn(formula=form,
#                    train=data[-idx[obj],],
#                    test=data[idx[obj],],
#                    k=1,
#                    distance=2,
#                    kernel="rectangular",
#                    scale=FALSE)
# 
#   pred=fitTrain$fitted.values
# 
#   filt=filt+1
# 
#   # Remove object if it was misclassified
# 
#   if(pred!=data[idx[obj],out]){
#     data=data[-idx[obj],]
#     idx=idx-1
#     removed=removed+1
#     cat("Filtered:",removed,"\n\n")
#     cat("Pre-filtered object:",filt,"\n\n")
#   }
# }

# Saving data and plotting

t1=(data[,"Qtn"]-min(data[,"Qtn"]))/(max(data[,"Qtn"])-min(data[,"Qtn"]))
t2=(data[,"Fr_p"]-min(data[,"Fr_p"]))/(max(data[,"Fr_p"])-min(data[,"Fr_p"]))
plot(sign(t1)*log10(1+(10^2-1)*abs(t1))/2,sign(t2)*log10(1+(10^2-1)*abs(t2))/2,col=data[,out])
saved_data=data

# New inputs

inp=c("Depth_m","qc_MPa","fs_kPa","u_kPa")

# Eliminating other attributes from data

datancol=ncol(data)
idxr=c()

for(i in 1:datancol){
  at=colnames(data)[i]
  if(length(inp[inp==at])==0){
    idxr=append(idxr,i)
  }
}

data=data[,-idxr]
mdata=as.matrix(data)

# Normalization by rescaling

minVal=c()

for(j in 1:length(inp)){
  minVal=cbind(minVal,min(mdata[,inp[j]]))
}

# Data frame with minimum values

minVal=as.matrix(minVal)
colnames(minVal)=inp

maxVal=c()

for(j in 1:length(inp)){
  maxVal=cbind(maxVal,max(mdata[,inp[j]]))
}

# Data frame with maximum values

maxVal=as.matrix(maxVal)
colnames(maxVal)=inp

# Normalizing

for(j in 1:length(inp)){
  
  mini=minVal[j]
  maxi=maxVal[j]
  
  cat("Normalizing",inp[j],"\n")
  
  for(obj in 1:nrow(mdata)){
    t=(mdata[obj,inp[j]]-mini)/(maxi-mini)
    mdata[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
  }
}

data=as.data.frame(mdata)

# Defining multiple synthetic datasets

nc=9 # Number of classes
nt=5 # Number of trials

# K-means clustering

kres <- kmeans(mdata,centers=nc,nstart=nt)

# C-means clustering

# cres=cmeans(mdata,centers=nc,iter.max=100)

# Kernel K-means clustering

# vec=sigest(mdata)
# sig=vec[2] #median
# kkres=kkmeans(mdata,centers=nc,kernel="rbfdot",kpar="automatic")

# # X-means clustering for KK-means

xkkres=xmeans(x=mdata,ik=2,iter.max=10,func="kkmeans")

# # X means clustering for C-means
# 
# xcres=xmeans(x=mdata,ik=2,iter.max=10,func="cmeans")

isg=saved_data$SBTn
fsb=saved_data$MSBTn

conf_isg=table(kkres,isg)[,-1]
conf_fsb=table(kkres,fsb)
conf_spt=table(tail(kkres,2847),confusion$Cspt)
conf_spt_91=table(tail(saved_data,2847)$SBTn,confusion$Cspt)
conf_spt_16=table(tail(saved_data,2847)$MSBTn,confusion$Cspt)
