mat=1
n0=4
n1=5
n2=4
w2=lowm[[mat]][(n0+1):(n1+n0),(n0+n1+1):(n0+n1+n2)]
w1=t(lowm[[mat]][1:n0,(n0+1):(n1+n0)])

w=w2

for(i in 1:nrow(w)){
  for(j in 1:ncol(w)){
    cat(w[i,j])
    if(j==ncol(w)){
      cat(" \n")
    }else{
      cat(",")
    }
  }
}

for(i in 1:length(unit)){
  cat(unit[i],"\\\\\n")
}

for(i in 1:nrow(centros)){
  for(j in 1:ncol(centros)){
    cat(i,"& ")
    cat(round(centros[i,j],2))
  }
  cat("\\\\\\hline\n")
}

conf=conf_spt_91

for(i in 1:nrow(conf)){
  if(sum(conf[i,])!=0){
    cat(i-1)
    for(j in 1:ncol(conf)){
      cat(" & ", round(100*conf[i,j]/sum(conf[i,]),2))
    }
    cat("\\\\\n")
  }
}

for(i in 1:nrow(conf)){
  cat(i)
  for(j in 1:ncol(conf)){
    cat(",", conf[i,j]/sum(conf[i,]),sep="")
  }
  cat("\n")
}
